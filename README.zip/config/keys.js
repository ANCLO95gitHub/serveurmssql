
// add this file to .gitignore

module.exports = {
  google: {
    clientID: '391937475951-uclbbagkvqgkfd2f9g4jnc71sgp0gesq.apps.googleusercontent.com',
    clientSecret: 'GMryJixk-_VNA4DzOh9vzrho'
  },
  mongodb: {
    dbURI: 'mongodb://iamshaunjp:test@ds151024.mlab.com:51024/oauth-test'
  },
  session:{
    cookieKey: 'thenetninjais'
  }
};
